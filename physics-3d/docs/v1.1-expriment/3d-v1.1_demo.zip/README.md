# Cocos Creator 3D - Physics 3D

The goal of this project is functional testing and case demonstration.

Files or folders in the `assets`:

- `cases`: functional testing
- `common`: common resources
- `demo`: case demonstration
- `misc`: some files that unimportant
- `resouces`: dynamic resources folder(`common/` mean it is a common dynamic resource; `simple-car/` mean it is a dynamic resource but just for `simple-car`)
- `TestList.scene`: a scene for test all case and demo, it is the default open scene but you can change the `preview start scene` in the setup item `Project/Project Setting/Project Preview`
